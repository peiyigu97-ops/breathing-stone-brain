"""
core/physio_clock.py — Seed-driven physiological activity profiles.

Every spontaneous spike in the brain is traceable:
    session_seed → region_seed → PhysioProfile → I_noise[t] → spike

Usage:
    clock = PhysioClock()          # random session seed
    clock = PhysioClock(seed=1234) # reproducible session
    profile = clock.profile_for("amygdala")
    I = profile.noise_current(t=0.0, n_neurons=50)
"""
from __future__ import annotations
import time
import numpy as np
from dataclasses import dataclass


# ── Per-region physiological baseline parameters ──────────────────────────────
# Based on known resting-state oscillation bands:
#   brainstem / amygdala  → higher tonic drive, faster threat response
#   frontal / parietal    → lower baseline, slower regulatory rhythms
#   thalamus              → strong rhythmic drive (thalamo-cortical loops)
#   cerebellum            → moderate, precision-timing oscillations

_REGION_PHYSIO: dict[str, dict] = {
    "frontal_cortex":  {"baseline_I": 2.5,  "osc_freq": 0.040, "osc_amp": 1.8, "noise_std": 1.2},
    "parietal_cortex": {"baseline_I": 2.8,  "osc_freq": 0.038, "osc_amp": 1.6, "noise_std": 1.1},
    "temporal_cortex": {"baseline_I": 2.6,  "osc_freq": 0.042, "osc_amp": 1.7, "noise_std": 1.2},
    "occipital_cortex":{"baseline_I": 2.4,  "osc_freq": 0.045, "osc_amp": 1.5, "noise_std": 1.0},
    # Insula: high tonic drive for continuous interoceptive monitoring
    "insula":          {"baseline_I": 3.4,  "osc_freq": 0.036, "osc_amp": 2.0, "noise_std": 1.4},
    # ACC: moderate baseline, active during conflict/salience detection
    "cingulate_cortex":{"baseline_I": 3.0,  "osc_freq": 0.038, "osc_amp": 1.9, "noise_std": 1.3},
    # OFC: low-medium baseline, reward-gated
    "orbitofrontal":   {"baseline_I": 2.6,  "osc_freq": 0.035, "osc_amp": 1.6, "noise_std": 1.1},
    "basal_ganglia":   {"baseline_I": 3.2,  "osc_freq": 0.028, "osc_amp": 2.0, "noise_std": 1.4},
    "thalamus":        {"baseline_I": 4.0,  "osc_freq": 0.055, "osc_amp": 2.8, "noise_std": 1.5},
    "hippocampus":     {"baseline_I": 3.0,  "osc_freq": 0.033, "osc_amp": 2.2, "noise_std": 1.3},
    "amygdala":        {"baseline_I": 3.8,  "osc_freq": 0.025, "osc_amp": 2.4, "noise_std": 1.6},
    # Hypothalamus: very high tonic drive — homeostatic pacemaker
    "hypothalamus":    {"baseline_I": 5.0,  "osc_freq": 0.015, "osc_amp": 3.2, "noise_std": 2.0},
    # LC: sparse neurons, high noise, burst-firing under stress
    "locus_coeruleus": {"baseline_I": 4.8,  "osc_freq": 0.018, "osc_amp": 3.5, "noise_std": 2.2},
    # SN: tonic dopamine pace; moderate oscillation
    "substantia_nigra":{"baseline_I": 3.6,  "osc_freq": 0.022, "osc_amp": 2.2, "noise_std": 1.6},
    "cerebellum":      {"baseline_I": 3.5,  "osc_freq": 0.060, "osc_amp": 2.0, "noise_std": 1.3},
    "brainstem":       {"baseline_I": 4.5,  "osc_freq": 0.020, "osc_amp": 3.0, "noise_std": 1.8},
}

_DEFAULT_PHYSIO = {"baseline_I": 3.0, "osc_freq": 0.035, "osc_amp": 2.0, "noise_std": 1.3}


@dataclass
class PhysioProfile:
    """
    Deterministic physiological activity profile for one brain region.
    All randomness is seeded — same region_seed always produces the same profile
    and the same noise sequence.
    """
    region_id:    str
    region_seed:  int
    baseline_I:   float   # tonic background current (mV equivalent)
    osc_freq:     float   # spontaneous oscillation frequency (cycles / step)
    osc_amp:      float   # oscillation amplitude
    noise_std:    float   # per-neuron Gaussian noise std
    phase_offset: float   # initial oscillation phase (radians)

    # internal RNG — seeded once, advanced deterministically
    _rng: np.random.Generator = None

    def __post_init__(self):
        self._rng = np.random.default_rng(self.region_seed)

    def noise_current(self, t: float, n_neurons: int) -> np.ndarray:
        """
        Return per-neuron background current at simulation step t.
        Traceable: region_seed → osc params → _rng sequence → this array.
        """
        osc = self.osc_amp * np.sin(2 * np.pi * self.osc_freq * t + self.phase_offset)
        noise = self._rng.normal(0.0, self.noise_std, n_neurons).astype(np.float32)
        return np.full(n_neurons, self.baseline_I + osc, dtype=np.float32) + noise

    def reset_rng(self):
        """Reset RNG to region_seed — makes a run fully reproducible."""
        self._rng = np.random.default_rng(self.region_seed)


class PhysioClock:
    """
    Session-level seed manager.
    Generates one PhysioProfile per brain region, all derived from session_seed.

    Traceability chain:
        session_seed
          └─ region_seed = int(sha256(session_seed || region_id)) % 2**31
               └─ PhysioProfile (baseline, freq, amp, phase)
                    └─ noise_current(t) → added to LIF I_ext each step
    """

    def __init__(self, seed: int | None = None):
        self.session_seed: int = seed if seed is not None else (int(time.time() * 1000) & 0x7FFFFFFF)
        self._profiles: dict[str, PhysioProfile] = {}
        print(f"[PhysioClock] session_seed={self.session_seed}  "
              f"(pass --seed {self.session_seed} to reproduce)")

    def _region_seed(self, region_id: str) -> int:
        import hashlib
        raw = f"{self.session_seed}:{region_id}".encode()
        return int(hashlib.sha256(raw).hexdigest()[:8], 16) & 0x7FFFFFFF

    def profile_for(self, region_id: str) -> PhysioProfile:
        if region_id not in self._profiles:
            rseed  = self._region_seed(region_id)
            base   = _REGION_PHYSIO.get(region_id, _DEFAULT_PHYSIO)
            # RNG for profile parameter jitter (±10%) — derived from region_seed
            jitter = np.random.default_rng(rseed)
            phase  = float(jitter.uniform(0, 2 * np.pi))
            self._profiles[region_id] = PhysioProfile(
                region_id    = region_id,
                region_seed  = rseed,
                baseline_I   = float(base["baseline_I"]  * jitter.uniform(0.92, 1.08)),
                osc_freq     = float(base["osc_freq"]    * jitter.uniform(0.90, 1.10)),
                osc_amp      = float(base["osc_amp"]     * jitter.uniform(0.88, 1.12)),
                noise_std    = float(base["noise_std"]   * jitter.uniform(0.90, 1.10)),
                phase_offset = phase,
            )
        return self._profiles[region_id]

    def summary(self) -> dict:
        """Return seed info for /api/seed endpoint."""
        return {
            "session_seed": self.session_seed,
            "regions": {
                rid: {
                    "region_seed":  p.region_seed,
                    "baseline_I":   round(p.baseline_I,  3),
                    "osc_freq":     round(p.osc_freq,    4),
                    "osc_amp":      round(p.osc_amp,     3),
                    "noise_std":    round(p.noise_std,   3),
                    "phase_offset": round(p.phase_offset,3),
                }
                for rid, p in self._profiles.items()
            },
        }
