"""
static_server.py — 本地HTTP服务器，serve v4_pyqt根目录
galaxy.html 位于 /static/galaxy.html
Three.js 位于 /static/js/three.module.js
"""
import threading
import socket
import urllib.parse
import mimetypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer

# Serve from the project root, not just static/
ROOT_DIR = Path(__file__).parent
PORT = 19876


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urllib.parse.unquote(self.path.split('?')[0])
        rel = path.lstrip('/')
        if not rel:
            rel = 'static/galaxy.html'

        target = (ROOT_DIR / rel).resolve()
        try:
            target.relative_to(ROOT_DIR.resolve())
        except ValueError:
            self._404(); return

        if not target.exists() or not target.is_file():
            self._404(); return

        mime, _ = mimetypes.guess_type(str(target))
        data = target.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', mime or 'application/octet-stream')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(data)

    def _404(self):
        self.send_response(404)
        self.end_headers()

    def log_message(self, *a):
        pass


_server = None


def start():
    global _server

    class S(HTTPServer):
        allow_reuse_address = True

    _server = S(("127.0.0.1", PORT), _Handler)
    threading.Thread(target=_server.serve_forever, daemon=True).start()


def stop():
    if _server:
        _server.shutdown()


def url(path: str = "static/galaxy.html") -> str:
    return f"http://127.0.0.1:{PORT}/{path.lstrip('/')}"
