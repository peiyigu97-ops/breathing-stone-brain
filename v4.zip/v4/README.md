# Chimera — Human Brain Digital Twin · v4

A real-time human brain simulation driven by a Leaky Integrate-and-Fire (LIF) neural network, rendered as a 3D galaxy visualization. Designed to explore the relationship between sensory input (touch, rhythm, thermal, threat) and anxiety regulation — the neural science backbone for the Breathing Stone therapeutic device.

---

## What's New in v4

| Area | Change |
|------|--------|
| **Architecture** | Replaced WebSocket + Gradio with PyQt6 + QWebChannel — eliminates the bandwidth bottleneck that caused freezing |
| **JS→Python comms** | Custom URL scheme (`pyqt://`) removed; QWebChannel provides non-blocking bidirectional communication |
| **Serialization** | JSON serialization moved to worker thread — main thread no longer blocks during stimulation |
| **Rendering** | Merged draw-call pools (stars / halos / satellites into 3 GPU draw calls); cloud shader uniforms throttled to 15fps |
| **DOM writes** | SVG labels and activity bars throttled to 10fps — reduces layout thrashing from ~480 style mutations/sec |
| **Signal cascade** | Removed recursive `triggerSignalCascade` — each stimulation spawns at most 12 fiber-optic signals, cleared on next input |
| **Simulation realism** | Dominant region determined by weighted firing rate (spikes/neuron × channel priority), not raw spike count |
| **Keyword mapping** | `stress`, `anxiety`, `threat`, `joy` remapped to neurologically correct primary channels |
| **Gain tuning** | Synaptic gain reduced from 400→80; per-channel input gains calibrated so threat dominates over rhythmic inputs |

---

## Requirements

```
PyQt6>=6.6.0
PyQt6-WebEngine>=6.6.0
numpy>=1.24.0
```

```bash
pip install PyQt6 PyQt6-WebEngine numpy
```

---

## Run

```bash
cd chimera/v4
python main.py
```

---

## Architecture

```
main.py
  └── QWebChannel ──────────────────── galaxy.html (Three.js 3D)
  └── BrainBridge
        └── BrainWorker (QThread)
              └── HumanBrain
                    └── BrainSimulator
                          └── RegionSimulator × 10  (LIF)
```

**Python → JS**: Worker emits pre-serialized JSON string via `state_ready` signal → `window.applyBrainState()`

**JS → Python**: Button/Enter triggers `bridge.stimulate(text)` via QWebChannel

---

## Simulation Model

**10 brain regions**: Frontal Cortex, Parietal Cortex/Insula, Temporal, Occipital, Basal Ganglia, Thalamus, Hippocampus, Amygdala, Cerebellum, Brainstem

**20 sensory channels**: touch_deep, touch_light, touch_vibration, thermal_warm, thermal_cold, rhythmic, interoception, threat_input, pain_input, anxiety_anticipatory, reward_signal, and more

**State memory**: `_anxiety_baseline` persists across stimulations — repeated threat inputs accumulate, repeated healing inputs reduce it. This models tonic ANS state, not episodic response.

**Outputs per stimulation**: ANS state (sympathetic/parasympathetic/HRV/cortisol), anxiety decomposition (baseline/anticipatory/somatic/regulation/healing_index), motor commands, polyvagal state, conduction path, dominant region.
