"""
main.py — PyQt6 窗口，QWebChannel 双向通信版本
"""
import sys
import os
from pathlib import Path

from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.QtCore import Qt, QTimer, pyqtSlot, QUrl, QObject, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebChannel import QWebChannel

from brain_bridge import BrainBridge
import static_server

BASE = Path(__file__).parent


class JsBridge(QObject):
    """
    暴露给 JS 的对象。JS 调用 stimulate(text) → 触发 Python 仿真。
    Python 仿真完成 → state_ready 信号 → JS 收到数据。
    """
    # Python → JS
    state_ready = pyqtSignal(str)

    def __init__(self, brain_bridge: BrainBridge, parent=None):
        super().__init__(parent)
        self._brain = brain_bridge
        # LIF 仿真结果直接转发给 JS
        self._brain.state_ready.connect(self.state_ready)
        self._brain.tick_ready.connect(self.state_ready)

    @pyqtSlot(str)
    def stimulate(self, text: str):
        """JS 调用此方法触发仿真，立即返回不阻塞。"""
        self._brain.stimulate(text)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Human Brain · Digital Twin")
        self.resize(1440, 900)
        self.showMaximized()

        # 初始化 brain bridge
        self._brain_bridge = BrainBridge(self)
        self._brain_bridge.start()

        # QWebChannel — 注册到页面
        self._channel = QWebChannel(self)
        self._js_bridge = JsBridge(self._brain_bridge, self)
        self._channel.registerObject("bridge", self._js_bridge)

        self.view = QWebEngineView()
        settings = self.view.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)

        self.view.page().setWebChannel(self._channel)
        self.view.page().javaScriptConsoleMessage = self._js_log
        self.view.loadFinished.connect(self._on_load)
        self.view.load(QUrl(static_server.url("static/galaxy.html")))
        self.setCentralWidget(self.view)

        self._tick = QTimer(self)
        self._tick.timeout.connect(self._brain_bridge.request_tick)

    def _js_log(self, level, msg, line, src):
        if msg and 'favicon' not in msg:
            print(f"[JS] {msg}")

    def _on_load(self, ok: bool):
        print(f"[MainWindow] page loaded ok={ok}")
        if ok:
            self._tick.start(200)

    def closeEvent(self, e):
        self._tick.stop()
        self._brain_bridge.stop()
        static_server.stop()
        super().closeEvent(e)


if __name__ == "__main__":
    for _k in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "all_proxy", "ALL_PROXY"):
        os.environ.pop(_k, None)
    os.environ["no_proxy"] = "127.0.0.1,localhost"
    os.environ["NO_PROXY"] = "127.0.0.1,localhost"
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
        "--enable-gpu-rasterization "
        "--proxy-bypass-list=127.0.0.1 "
        "--no-proxy-server"
    )

    static_server.start()
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    win = MainWindow()
    win.show()
    sys.exit(app.exec())
