"""
test_window.py — 最简单的测试，确认PyQt6窗口能正常显示
"""
import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel
from PyQt6.QtCore import Qt
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QUrl
from pathlib import Path

BASE = Path(__file__).parent

app = QApplication(sys.argv)

win = QMainWindow()
win.setWindowTitle("Test")
win.resize(1200, 800)
win.setStyleSheet("background: #07080f; color: white;")

# 先测试纯HTML字符串能不能显示
view = QWebEngineView()
view.setHtml("""
<!DOCTYPE html>
<html>
<head>
<style>
body { background: #000; color: #fff; font-family: sans-serif; display:flex; align-items:center; justify-content:center; height:100vh; margin:0; }
h1 { color: #4a90d9; }
</style>
</head>
<body>
<div>
  <h1>WebEngine Working</h1>
  <p style="color:#888">If you see this, QWebEngineView is functional</p>
</div>
</body>
</html>
""")

win.setCentralWidget(view)
win.show()

print("Window shown, waiting...")
sys.exit(app.exec())
