"""
brain_bridge.py — 替代 WebSocket server，直接在 Qt 线程里驱动 LIF 仿真。
PyQt6 Signal 替代 WebSocket broadcast。
"""
from __future__ import annotations
import json
import time
from PyQt6.QtCore import QObject, pyqtSignal, QThread, pyqtSlot

from HumanBrainDT.brain import HumanBrain
from HumanBrainDT.core.signal import BrainState, ANSState


def _pv_state(ans: ANSState) -> str:
    """Polyvagal ladder: ventral vagal / sympathetic / dorsal vagal."""
    if ans.parasympathetic > 0.4 and ans.hrv_index > 0.5:
        return "ventral"
    if ans.sympathetic > 0.35:
        return "sympathetic"
    return "dorsal"


class BrainWorker(QObject):
    """
    在独立线程里运行 LIF 仿真，避免阻塞 UI。
    stimulate() 是槽，state_ready 是信号。
    """
    state_ready   = pyqtSignal(str)    # 仿真完成 → 推预序列化 JSON 给前端
    tick_ready    = pyqtSignal(str)    # 自发放电 tick → 推节点活动

    def __init__(self):
        super().__init__()
        self._brain: HumanBrain | None = None

    @pyqtSlot()
    def init_brain(self):
        """在 worker 线程里初始化大脑（防止主线程卡住）"""
        self._brain = HumanBrain()

    @pyqtSlot(str)
    def stimulate(self, text: str):
        if self._brain is None:
            return
        state: BrainState = self._brain.stimulate(text)
        payload = self._brain.state_to_dict(state)
        # 包装成和原 WebSocket 一样的格式，让 galaxy.html 无需改动
        nodes = [
            {
                "id":        rid,
                "label":     r.label if hasattr(r, 'label') else rid,
                "spikes":    int(state.region_activity.get(rid, 0)),
                "activity":  round(min(1.0, state.region_activity.get(rid, 0) / 5000), 4),
                "n_neurons": r.population.n_neurons,
            }
            for rid, r in self._brain.regions.items()
        ]
        msg = {
            "nodes": nodes,
            "ts":    time.time(),
            "event": {
                "type":            "stimulate",
                "text":            text,
                "experience":      payload["experience"],
                "dominant":        payload["dominant_region"],
                "total_spikes":    payload["total_spikes"],
                "motor":           payload["motor_command"],
                "ans":             payload["ans"],
                "anxiety":        payload["anxiety"],
                "sensory":         payload["sensory"],
                "conduction_path": payload["conduction_path"],
                "pv_state":        _pv_state(state.ans),
            },
        }
        # Serialize on worker thread — keeps main thread free
        js = json.dumps(msg, ensure_ascii=False).replace("\\", "\\\\").replace("'", "\\'")
        self.state_ready.emit(js)

    @pyqtSlot()
    def tick(self):
        """自发放电快照（定时器调用）"""
        if self._brain is None:
            return
        nodes = [
            {
                "id":       rid,
                "spikes":   r.spike_count(),
                "activity": round(min(1.0, r.spike_count() / 5000), 4),
            }
            for rid, r in self._brain.regions.items()
        ]
        tick_msg = json.dumps({"nodes": nodes, "ts": time.time()}, ensure_ascii=False).replace("\\", "\\\\").replace("'", "\\'")
        self.tick_ready.emit(tick_msg)


class BrainBridge(QObject):
    """
    主线程持有这个对象。
    把 BrainWorker 放进 QThread，提供简单的接口给 MainWindow 调用。
    """
    state_ready = pyqtSignal(str)
    tick_ready  = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._thread = QThread()
        self._worker = BrainWorker()
        self._worker.moveToThread(self._thread)

        # 线程启动 → 初始化大脑
        self._thread.started.connect(self._worker.init_brain)

        # worker 信号透传给外部
        self._worker.state_ready.connect(self.state_ready)
        self._worker.tick_ready.connect(self.tick_ready)

    def start(self):
        self._thread.start()

    def stop(self):
        self._thread.quit()
        self._thread.wait()

    def stimulate(self, text: str):
        """主线程调用，跨线程触发 worker.stimulate"""
        from PyQt6.QtCore import QMetaObject, Qt, Q_ARG
        QMetaObject.invokeMethod(
            self._worker, "stimulate",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, text),
        )

    def request_tick(self):
        from PyQt6.QtCore import QMetaObject, Qt
        QMetaObject.invokeMethod(
            self._worker, "tick",
            Qt.ConnectionType.QueuedConnection,
        )
